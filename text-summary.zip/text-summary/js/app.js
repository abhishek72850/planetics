$(function(){
	$('#loader').hide();
	$('.analysis_loader').hide();
	$('.screen_loader').hide();

	$('.result_page_nav').prop(true);

	// create a scene
	new ScrollMagic.Scene({
	    //duration: 100, // the scene should last for a scroll distance of 100px
	    offset: 50 // start this scene after scrolling for 50px
	}).setPin('#search_panel_pin',{pushFollowers: false}).addTo(controller);

	new ScrollMagic.Scene({
	    //duration: 100, // the scene should last for a scroll distance of 100px
	    offset: 0 // start this scene after scrolling for 50px
	}).setPin('#nav',{pushFollowers: false}).addTo(controller);


	$('#cancel_analysis').on('click', function(){
		planetics.xhr.abort();
		$('.analysis_loader').hide();
		$('.analysis_cont').hide();
		$('.screen_loader').hide();
	});

	$('body').delegate('#analyse','click',function(){
		if(this.dataset.type == 'dialog'){
			$('.analysis_cont').hide();
			$('.screen_loader').hide();
		}
		else{
			$('.analysis_loader').hide();
			$('.analysis_cont').show();
			$('.analysis_head').show();
			$('.analysis_details').show();
			$('.analysis_operate').show();
		}
	});
});